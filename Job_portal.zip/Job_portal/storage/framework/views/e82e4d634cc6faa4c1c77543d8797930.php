<?php $__env->startSection('content'); ?>

<?php if (isset($component)) { $__componentOriginalf3c03d10aaf0546e1453246bc619f3e1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf3c03d10aaf0546e1453246bc619f3e1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pencarian','data' => ['variant' => 'perusahaan']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pencarian'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'perusahaan']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf3c03d10aaf0546e1453246bc619f3e1)): ?>
<?php $attributes = $__attributesOriginalf3c03d10aaf0546e1453246bc619f3e1; ?>
<?php unset($__attributesOriginalf3c03d10aaf0546e1453246bc619f3e1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf3c03d10aaf0546e1453246bc619f3e1)): ?>
<?php $component = $__componentOriginalf3c03d10aaf0546e1453246bc619f3e1; ?>
<?php unset($__componentOriginalf3c03d10aaf0546e1453246bc619f3e1); ?>
<?php endif; ?>

<div class="container-all">
    <div class="popular-categories">
        <h2>Daftar Perusahaan</h2>
        <div class="Perusahaan-buttons">
            <?php $__currentLoopData = $datapr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perusahaan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <button onclick="goToPerusahaan('<?php echo e($perusahaan->id); ?>')" class="btn btn-primary">
                <div class="card-body p-4">
                    <img src="<?php echo e(asset('storage/foto_user/'.$perusahaan->foto)); ?>" alt="perusahaan" class="w-50
                    h-50">
                    <h5 class="card-title"><?php echo e($perusahaan->nama); ?></h5>
                    <p class="card-text">Jakarta, Indonesia</p>
                </div>
            </button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>

<script>
    function goToPerusahaan(id) {
        window.location.href = `/perusahaandetail/${id}`;
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\Documents\project-php\laravel\Job_portal\resources\views/components/list-perusahaan.blade.php ENDPATH**/ ?>