<footer class="footer text-center py-4">
    <div class="container">
        <img src="<?php echo e(asset('images/wnn3.png')); ?>" alt="" class="footer-logo me-5" width="20">
        <h3 class="mt-3">Contact Us</h3>
        
        <div class="social-icons mt-2"><a href="#" class="social-icon"><i class="fab fa-facebook"></i></a>
            <a href="#" class="social-icon"><i class="fab fa-twitter"></i></a>
            <a href="#" class="social-icon"><i class="fab fa-instagram"></i></a>
            <a href="#" class="social-icon"><i class="fab fa-linkedin"></i></a>
        </div>
    </div>
</footer>
<?php /**PATH C:\Users\ASUS\Documents\project-php\laravel\Job_portal\resources\views/components/footer.blade.php ENDPATH**/ ?>