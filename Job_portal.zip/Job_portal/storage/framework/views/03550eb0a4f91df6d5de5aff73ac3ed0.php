

<?php $__env->startSection('content'); ?>
<div class="container-box-tentangkami">
    <div class="box-tentangkami">
        <img src="<?php echo e(asset('images/wnn3.png')); ?>" alt="">
        <div class="box-desc">
            <h3>Descripsi</h3> 
          </div>
          <hr class="my-4 border border-light border-3">

          <div class="visi-misi">
            <div class="box">
                <h3>Visi</h3>
              </div>
              <div class="box">
                <h3>Misi</h3>
              </div>
          </div>
         
         
          
    </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\Documents\project-php\laravel\Job_portal\resources\views/pages/tentangkami.blade.php ENDPATH**/ ?>