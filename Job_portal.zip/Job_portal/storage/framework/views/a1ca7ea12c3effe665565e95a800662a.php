

<?php $__env->startSection('title', request()->routeIs('Login') ? 'Login' : 'Register'); ?>
<?php $__env->startSection('content'); ?>
<div class="auth-container w-50">
    <?php if(request()->routeIs('login')|| request()->routeIs('Register')): ?>
    <form class="form needs" action="<?php echo e(request()->routeIs('login') ? '/loginproses' : route('register.proses')); ?>" method="post"
        enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="header">
            <h2><?php echo e(request()->routeIs('login') ? 'Login' : 'Register'); ?></h2>
        </div>
        <div>
            <?php if(request()->routeIs('Register')): ?>
            <div class="mb-3">
                <label for="nama">Nama Lengkap</label>
                <input type="text" name="nama" aria-describedby="validationServerNamaFeedback">
                <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div id="emailHelp" class="form-text text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <?php endif; ?>
            <label for="email">Alamat Email</label>
            <input type="email" id="email" name="email">
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div id="emailHelp" class="form-text text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="pw">
            <label for="password">Password</label>
            <input type="password" id="password" name="password">
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div id="emailHelp" class="form-text text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <?php if(request()->routeIs('Register')): ?>
        <div class="pw">
            <label for="cmpassword">Comfirm Password</label>
            <input type="password" id="cmpassword" name="confrmpassword">
            <?php $__errorArgs = ['confrmpassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div id="emailHelp" class="form-text text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="checkbox" value="true" id="checkChecked" name="perusahaan">
            <label class="form-check-label" for="checkChecked">
                Daftar Sebagai Perusahan
            </label>
        </div>
        <?php endif; ?>
        <a href="/forgetpassword" class="forgot-password">Lupa password?</a>
        <button type="submit"><?php echo e(request()->routeIs('login') ? 'login' : 'Register'); ?></button>
        <p class="register"><?php echo e(request()->routeIs('login') ? 'Belum Punya Akun?' : 'Sudah punya Akun?'); ?> <a
                href="<?php echo e(request()->routeIs('login') ? '/register' : '/login'); ?>"><?php echo e(request()->routeIs('login') ? 'klik untuk register' : 'klik untuk login'); ?></a>
        </p>
    </form>
    <?php endif; ?>
    <?php if(request()->routeIs('forgetpassword')): ?>
    <div class="d-flex w-100">
        <div class="logo-reset">
            <img src="<?php echo e(asset('images/wnn3.png')); ?>" alt="Winn Jobs Logo" height="50" width="180">
        </div>
        <form action="<?php echo e(route('password.send')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="Reset-container w-100">
                <div class="form-reset">
                    <div class="header-reset">
                        <h2>Lupa Password</h2>
                    </div>
                    <div style="margin-bottom: 20px">Masukkan email untuk reset password</div>
                    <div class="w-100">
                        <label for="email">Alamat Email</label>
                        <input type="email" id="email" name="email">
                    </div>
                    <button style="margin-top: 10px" type="submit" class="btn btn-primary">Reset</button>
                </div>
            </div>
        </form>
    </div>
    <?php endif; ?>
    <?php if(request()->routeIs('reset.password')): ?>
    <div class="logo-reset">
        <img src="<?php echo e(asset('images/wnn3.png')); ?>" alt="Winn Jobs Logo" height="50" width="180">
    </div>
    <div class="Reset-container">

        <div class="form-reset">
            <div class="header-reset">
                <h2>Cek email anda !</h2>
            </div>
            <div style="margin-bottom: 20px">Kami mengirimkan link reset ke email Anda, masukkan 4 digit kode
                yang disebutkan dalam email.
            </div>
            <div>
                <form action="<?php echo e(route('password.verify')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="email" value="<?php echo e($email); ?>">
                    <label>Kode</label>
                    <input type="number" name="kode">
                    <button style="margin-top: 10px" type="submit" class="btn btn-primary">Verif Kode</button>
                </form>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <?php if(request()->routeIs('newpassword')): ?>
    <div class="logo-reset">
        <img src="<?php echo e(asset('images/wnn3.png')); ?>" alt="Winn Jobs Logo" height="50" width="180">
    </div>
    <div class="Reset-container">

        <div class="form-reset">
            <div class="header-reset">
                <h2>Masukkan Password Baru Anda</h2>
            </div>
            <div>
                <form action="<?php echo e(route('addnewpassword')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="email" value="<?php echo e($email); ?>">
                    <label>New Password</label>
                    <input type="password" name="password">
                    <button style="margin-top: 10px" type="submit" class="btn btn-primary">New Password!</button>
                </form>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\Documents\project-php\laravel\Job_portal\resources\views/Components/Auth.blade.php ENDPATH**/ ?>