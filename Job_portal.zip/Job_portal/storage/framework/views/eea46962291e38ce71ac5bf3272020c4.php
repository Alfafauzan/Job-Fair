
<?php $__env->startSection('content'); ?>
<div class="container-all">
    <div class="rekomendasi">
        <div class="rekomendasi-list">
            <?php $__currentLoopData = $data_lowongan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="rekomendasi-item">
                <div class="rekomendasi-image">
                    <img src="<?php echo e(asset('storage/foto_user/'.$data->perusahaan->foto)); ?>" alt="Gambar Rekomendasi">
                </div>
                <div class="rekomendasi-content">
                    <h3><?php echo e($data->perusahaan->nama); ?></h3>
                    <p>Open Position for <?php echo e($data->judul_lowongan); ?></p>
                    <p><?php echo e($data->lokasi); ?></p>
                    <p><?php echo e($data->tipe_pekerjaan); ?></p>
                    <p>Rp.<?php echo e(number_format($data->gaji_manimum)); ?>-Rp.<?php echo e(number_format($data->gaji_maximum)); ?></p>

                </div>
                <a href="<?php echo e(route('statusjobs',$data->id)); ?>" class="rekomendasi-button">Lihat +</a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\Documents\project-php\laravel\Job_portal\resources\views/pages/jobkategori.blade.php ENDPATH**/ ?>