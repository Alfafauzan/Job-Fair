 <div id="joblistSection" style="display: none;">
     <?php if(Auth::user()->role==="perusahaan"): ?>
     <a href="javascript:void(0)" onclick="showPostJob()" class="post-button">Post New Job</a>
     <?php endif; ?>
     <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datajobs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <div class="job-card">
         <div class="job-info">
             <img src="<?php echo e(asset('storage/foto_user/'.$datajobs->perusahaan->foto)); ?>" alt="Company Logo">
             <div class="job-text">
                 <small><?php echo e($datajobs->perusahaan->nama); ?></small>
                 <strong><?php echo e($datajobs["judul_lowongan"]); ?></strong>
                 <small><?php echo e($datajobs["deskripsi_lowongan"]); ?></small>
             </div>
         </div>
         <a href="<?php echo e(route('statusjobs',$datajobs->id)); ?>" class="lihat-btn">
             Lihat →
         </a>
     </div>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </div>
 <div id="postJobSection" style="display: none;">
     <?php if (isset($component)) { $__componentOriginalb5c41d149848d802fba88ff4bd55822f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb5c41d149848d802fba88ff4bd55822f = $attributes; } ?>
<?php $component = App\View\Components\PostJob::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('PostJob'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\PostJob::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb5c41d149848d802fba88ff4bd55822f)): ?>
<?php $attributes = $__attributesOriginalb5c41d149848d802fba88ff4bd55822f; ?>
<?php unset($__attributesOriginalb5c41d149848d802fba88ff4bd55822f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb5c41d149848d802fba88ff4bd55822f)): ?>
<?php $component = $__componentOriginalb5c41d149848d802fba88ff4bd55822f; ?>
<?php unset($__componentOriginalb5c41d149848d802fba88ff4bd55822f); ?>
<?php endif; ?>
     <button type="button" onclick="cancelPostJob()" class="lihat-btn">Cancel</button>
 </div>

 <script>
     function showPostJob() {
         document.getElementById('joblistSection').style.display = 'none';
         document.getElementById('postJobSection').style.display = 'block';
     }

     function cancelPostJob() {
         document.getElementById('postJobSection').style.display = 'none';
         document.getElementById('joblistSection').style.display = 'block';
     }
 </script><?php /**PATH C:\Users\ASUS\Documents\project-php\laravel\Job_portal\resources\views/components/joblist.blade.php ENDPATH**/ ?>