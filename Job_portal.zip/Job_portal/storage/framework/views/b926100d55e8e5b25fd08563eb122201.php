<?php if(session("success_lowongan")): ?>
<?php if (isset($component)) { $__componentOriginalfe23274bac8361bb4f6fc496b9a81aa0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfe23274bac8361bb4f6fc496b9a81aa0 = $attributes; } ?>
<?php $component = App\View\Components\Showalert::resolve(['type' => 'success','title' => 'Well done!','footer' => ''.e(session('success_lowongan')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('showalert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Showalert::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfe23274bac8361bb4f6fc496b9a81aa0)): ?>
<?php $attributes = $__attributesOriginalfe23274bac8361bb4f6fc496b9a81aa0; ?>
<?php unset($__attributesOriginalfe23274bac8361bb4f6fc496b9a81aa0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfe23274bac8361bb4f6fc496b9a81aa0)): ?>
<?php $component = $__componentOriginalfe23274bac8361bb4f6fc496b9a81aa0; ?>
<?php unset($__componentOriginalfe23274bac8361bb4f6fc496b9a81aa0); ?>
<?php endif; ?>
<?php endif; ?>
<?php if(session("gagal_lowongan")): ?>
<?php if (isset($component)) { $__componentOriginalfe23274bac8361bb4f6fc496b9a81aa0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfe23274bac8361bb4f6fc496b9a81aa0 = $attributes; } ?>
<?php $component = App\View\Components\Showalert::resolve(['type' => 'danger','title' => 'Well fail!','footer' => ''.e(session('gagal_lowongan')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('showalert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Showalert::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfe23274bac8361bb4f6fc496b9a81aa0)): ?>
<?php $attributes = $__attributesOriginalfe23274bac8361bb4f6fc496b9a81aa0; ?>
<?php unset($__attributesOriginalfe23274bac8361bb4f6fc496b9a81aa0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfe23274bac8361bb4f6fc496b9a81aa0)): ?>
<?php $component = $__componentOriginalfe23274bac8361bb4f6fc496b9a81aa0; ?>
<?php unset($__componentOriginalfe23274bac8361bb4f6fc496b9a81aa0); ?>
<?php endif; ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal26fc81bb1653a89c1c467cbab2aa4984 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal26fc81bb1653a89c1c467cbab2aa4984 = $attributes; } ?>
<?php $component = App\View\Components\ViewJobs::resolve(['id' => $id] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('viewJobs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ViewJobs::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal26fc81bb1653a89c1c467cbab2aa4984)): ?>
<?php $attributes = $__attributesOriginal26fc81bb1653a89c1c467cbab2aa4984; ?>
<?php unset($__attributesOriginal26fc81bb1653a89c1c467cbab2aa4984); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal26fc81bb1653a89c1c467cbab2aa4984)): ?>
<?php $component = $__componentOriginal26fc81bb1653a89c1c467cbab2aa4984; ?>
<?php unset($__componentOriginal26fc81bb1653a89c1c467cbab2aa4984); ?>
<?php endif; ?><?php /**PATH C:\Users\ASUS\Documents\project-php\laravel\Job_portal\resources\views/pages/viewjobs.blade.php ENDPATH**/ ?>