<nav class="navbar navbar-expand-lg bg-body-white">
    <div class="container">
        <a href="<?php echo e(route($navbarType . '.home')); ?>" id="homelink">
            <img src="<?php echo e(asset('images/wnn3.png')); ?>" alt="" width="180" height="50">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown"
            aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav ms-3">

                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('lowongan') ? 'active' : ''); ?>"
                        href="<?php echo e(route('lowongan')); ?>" id="lowonganlink">Lowongan Kerja</a>
                </li>

                <?php if(Auth::check() && Auth::user()->role==="perusahaan"): ?>
                <a class="nav-link <?php echo e(request()->is('/listpelamar') ? 'active' : ''); ?>"
                    href="<?php echo e(route($navbarType . '.listPelamar')); ?>" id="lowonganlink">List Pelamar</a>
                <?php endif; ?>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs($navbarType . '.listPerusahaan') ? 'active' : ''); ?>"
                        href="<?php echo e(route($navbarType . '.listPerusahaan')); ?>">
                        Perusahaan
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs($navbarType . '.tentangkami') ? 'active' : ''); ?>"
                        href="<?php echo e(route($navbarType . '.tentangkami')); ?>">
                        Tentang Kami
                    </a>
                </li>
            </ul>
            <ul class="navbar-nav navbar-right-section">
                <li class="nav-item dropdown ms-3">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                        aria-expanded="false">
                        Bahasa
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="#">Indonesia</a></li>
                        <li><a class="dropdown-item" href="#">Bahasa Inggris</a></li>
                    </ul>
                </li>

                <?php if(!Auth::check()): ?>
                <div style="display: flex; gap: 2px;">
                    <li class="nav-item"><a href="/login" class="btn btn-masuk ms-3">Masuk</a></li>
                    <li class="nav-item"><a href="/register" class="btn btn-perusahaan ms-2">Daftar</a></li>
                </div>
                <?php endif; ?>
                <?php if(Auth::check()): ?>
                <li class="nav-item dropdown ms-3">
                    <img class="nav-link dropdown-toggle rounded-circle  " style="height: 50px; width: 50px;"
                        href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"
                        src="<?php echo e(asset('storage/foto_user/'.Auth::user()->foto)); ?>" alt="">

                    <ul class="dropdown-menu">
                        <a class="dropdown-item" href="<?php echo e(Auth::user()->role === 'pelamar' ? '/profilPelamar' : '/about-perusahaan'); ?>">Profile</a>
                        <li><a class="dropdown-item" href="/logout">Keluar</a></li>
                    </ul>
                </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav><?php /**PATH C:\Users\ASUS\Documents\project-php\laravel\Job_portal\resources\views/components/navbar.blade.php ENDPATH**/ ?>