<?php if (isset($component)) { $__componentOriginale7c1da47fc542bb0765e17fb8b317afd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale7c1da47fc542bb0765e17fb8b317afd = $attributes; } ?>
<?php $component = App\View\Components\ListPerusahaan::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('listPerusahaan'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ListPerusahaan::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale7c1da47fc542bb0765e17fb8b317afd)): ?>
<?php $attributes = $__attributesOriginale7c1da47fc542bb0765e17fb8b317afd; ?>
<?php unset($__attributesOriginale7c1da47fc542bb0765e17fb8b317afd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale7c1da47fc542bb0765e17fb8b317afd)): ?>
<?php $component = $__componentOriginale7c1da47fc542bb0765e17fb8b317afd; ?>
<?php unset($__componentOriginale7c1da47fc542bb0765e17fb8b317afd); ?>
<?php endif; ?><?php /**PATH C:\Users\ASUS\Documents\project-php\laravel\Job_portal\resources\views/pages/listPerusahaan.blade.php ENDPATH**/ ?>