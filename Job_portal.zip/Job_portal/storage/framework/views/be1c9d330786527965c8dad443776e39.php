

<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginalf3c03d10aaf0546e1453246bc619f3e1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf3c03d10aaf0546e1453246bc619f3e1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pencarian','data' => ['withLocation' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pencarian'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['withLocation' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf3c03d10aaf0546e1453246bc619f3e1)): ?>
<?php $attributes = $__attributesOriginalf3c03d10aaf0546e1453246bc619f3e1; ?>
<?php unset($__attributesOriginalf3c03d10aaf0546e1453246bc619f3e1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf3c03d10aaf0546e1453246bc619f3e1)): ?>
<?php $component = $__componentOriginalf3c03d10aaf0546e1453246bc619f3e1; ?>
<?php unset($__componentOriginalf3c03d10aaf0546e1453246bc619f3e1); ?>
<?php endif; ?>

    
    <div class="container-all">


        
        <h2>List Pelamar</h2>
        <div class="rekomendasi">
            <div class="rekomendasi-list">
                <?php for($i = 0; $i < 2; $i++): ?>
                    <div class="rekomendasi-item">
                        <div class="rekomendasi-image">
                            
                            <img src="<?php echo e(asset('images/placeholder.png')); ?>" alt="Gambar Rekomendasi">
                        </div>
                        <div class="rekomendasi-content">
                            <h3>Nama Pelamar</h3>
                            <p>Keahlian nya</p>
                            <p>Bio datanya</p>
                        </div>
                        <a href="/pelamarDetail" class="rekomendasi-button">Lihat +</a>
                    </div>
                <?php endfor; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\Documents\project-php\laravel\Job_portal\resources\views/pages/listPelamar.blade.php ENDPATH**/ ?>