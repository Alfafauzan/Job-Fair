

<?php $__env->startSection('content'); ?>

<?php if (isset($component)) { $__componentOriginalf3c03d10aaf0546e1453246bc619f3e1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf3c03d10aaf0546e1453246bc619f3e1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pencarian','data' => ['withLocation' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pencarian'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['withLocation' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf3c03d10aaf0546e1453246bc619f3e1)): ?>
<?php $attributes = $__attributesOriginalf3c03d10aaf0546e1453246bc619f3e1; ?>
<?php unset($__attributesOriginalf3c03d10aaf0546e1453246bc619f3e1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf3c03d10aaf0546e1453246bc619f3e1)): ?>
<?php $component = $__componentOriginalf3c03d10aaf0546e1453246bc619f3e1; ?>
<?php unset($__componentOriginalf3c03d10aaf0546e1453246bc619f3e1); ?>
<?php endif; ?>



<?php if(!Auth::check()): ?>
<h1 class="text-center m-0 py-5 px-3">Cari lowongan yang anda inginkan</h1>
<div class="container-box-pendaftaran">
    <div class="box-pendaftaran">
        <div class="tombol-pendaftaran">
            <a href="/login" class="login">Masuk</a>
            <a href="/register" class="register">Daftar</a>
        </div>
        <div class="description">
            <p>Masuk untuk mengelola profil JobStreet, menyimpan pencarian kerja, dan melihat lowongan yang
                disarankan untuk Anda.</p>
        </div>
    </div>
</div>

<?php endif; ?>

<?php if (isset($component)) { $__componentOriginalf87ce31aae2745b13fd755fe1088c54f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf87ce31aae2745b13fd755fe1088c54f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.kategori','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('kategori'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf87ce31aae2745b13fd755fe1088c54f)): ?>
<?php $attributes = $__attributesOriginalf87ce31aae2745b13fd755fe1088c54f; ?>
<?php unset($__attributesOriginalf87ce31aae2745b13fd755fe1088c54f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf87ce31aae2745b13fd755fe1088c54f)): ?>
<?php $component = $__componentOriginalf87ce31aae2745b13fd755fe1088c54f; ?>
<?php unset($__componentOriginalf87ce31aae2745b13fd755fe1088c54f); ?>
<?php endif; ?>

<?php if(request()->routeIs('lowongan')): ?>
<h4 class="text-center">Daftar Pekerjaan Terbaru</h4>
<?php if (isset($component)) { $__componentOriginala22e1dbc94675f04b4d6a1a08ad82767 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala22e1dbc94675f04b4d6a1a08ad82767 = $attributes; } ?>
<?php $component = App\View\Components\ListPekerjaan::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('listPekerjaan'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ListPekerjaan::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala22e1dbc94675f04b4d6a1a08ad82767)): ?>
<?php $attributes = $__attributesOriginala22e1dbc94675f04b4d6a1a08ad82767; ?>
<?php unset($__attributesOriginala22e1dbc94675f04b4d6a1a08ad82767); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala22e1dbc94675f04b4d6a1a08ad82767)): ?>
<?php $component = $__componentOriginala22e1dbc94675f04b4d6a1a08ad82767; ?>
<?php unset($__componentOriginala22e1dbc94675f04b4d6a1a08ad82767); ?>
<?php endif; ?>
<?php endif; ?>

<?php if(request()->routeIs('home')): ?>

<?php if (isset($component)) { $__componentOriginalb2688852c5489493d0123e506be9de3b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb2688852c5489493d0123e506be9de3b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.carousel','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('carousel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb2688852c5489493d0123e506be9de3b)): ?>
<?php $attributes = $__attributesOriginalb2688852c5489493d0123e506be9de3b; ?>
<?php unset($__attributesOriginalb2688852c5489493d0123e506be9de3b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb2688852c5489493d0123e506be9de3b)): ?>
<?php $component = $__componentOriginalb2688852c5489493d0123e506be9de3b; ?>
<?php unset($__componentOriginalb2688852c5489493d0123e506be9de3b); ?>
<?php endif; ?>

<?php if (isset($component)) { $__componentOriginalde4fc542bac8598509436b7207513ad4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalde4fc542bac8598509436b7207513ad4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.cv-tutor','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('cv-tutor'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalde4fc542bac8598509436b7207513ad4)): ?>
<?php $attributes = $__attributesOriginalde4fc542bac8598509436b7207513ad4; ?>
<?php unset($__attributesOriginalde4fc542bac8598509436b7207513ad4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalde4fc542bac8598509436b7207513ad4)): ?>
<?php $component = $__componentOriginalde4fc542bac8598509436b7207513ad4; ?>
<?php unset($__componentOriginalde4fc542bac8598509436b7207513ad4); ?>
<?php endif; ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\Documents\project-php\laravel\Job_portal\resources\views/pages/home.blade.php ENDPATH**/ ?>