

<?php $__env->startSection('content'); ?>
<div class="profilperusahaan ">
    <?php if(session("success_lowongan")): ?>
    <?php if (isset($component)) { $__componentOriginalfe23274bac8361bb4f6fc496b9a81aa0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfe23274bac8361bb4f6fc496b9a81aa0 = $attributes; } ?>
<?php $component = App\View\Components\Showalert::resolve(['type' => 'success','title' => 'Well done!','footer' => ''.e(session('success_lowongan')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('showalert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Showalert::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfe23274bac8361bb4f6fc496b9a81aa0)): ?>
<?php $attributes = $__attributesOriginalfe23274bac8361bb4f6fc496b9a81aa0; ?>
<?php unset($__attributesOriginalfe23274bac8361bb4f6fc496b9a81aa0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfe23274bac8361bb4f6fc496b9a81aa0)): ?>
<?php $component = $__componentOriginalfe23274bac8361bb4f6fc496b9a81aa0; ?>
<?php unset($__componentOriginalfe23274bac8361bb4f6fc496b9a81aa0); ?>
<?php endif; ?>
    <?php endif; ?>
    <div class="profile-card shadow mb-5">
        <img src="<?php echo e(asset('storage/foto_user/'.Auth::user()->foto)); ?>" alt="Profile">
        <div class="profile-name"><?php echo e(Auth::user()->nama); ?></div>
    </div>
    
    <div class="d-flex justify-content-between align-items-center gap-5 border-bottom pb-3 mb-4">
        <button onclick="showSection('aboutSection')" id="btn-about"
            class="tab-link text-primary border-bottom border-primary fw-bold bg-transparent border-0">About</button>
        <button onclick="showSection('joblistSection')" id="btn-listjob"
            class="tab-link text-dark bg-transparent border-0">Job List</button>
        <button onclick="showSection('contactSection')" id="btn-contact"
            class="tab-link text-dark bg-transparent border-0">Contact</button>
    </div>

    


<div id="aboutSection">
    <div class="box-about">
        <div class="box-descripsi">
            <h3>Descripsi</h3>
            <hr>
            <?php echo e(Auth::user()->detailUser->deskripsi_pribadi?? "belum dibuat"); ?>

        </div>
        <hr class="my-4 border border-light border-3">

        <div class="visi-misi-about">
            <div class="box-visi-misi">
                <h3>Visi</h3>
                <hr>
                <?php echo e(Auth::user()->detailUser->visi?? "belum dibuat"); ?>

            </div>
            <div class="box-visi-misi">
                <h3>Misi</h3>
                <hr>
                <?php echo e(Auth::user()->detailUser->misi?? "belum dibuat"); ?>

            </div>
        </div>
    </div>

    <div class="edit-button">
        <a href="/editprofil-perusahaan" class="btn btn-primary shadow px-4">Edit Profile</a>
    </div>
</div>


<?php if (isset($component)) { $__componentOriginald0cc230b3d9e5893ce7018dd9bf7aac9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0cc230b3d9e5893ce7018dd9bf7aac9 = $attributes; } ?>
<?php $component = App\View\Components\Joblist::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('joblist'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Joblist::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0cc230b3d9e5893ce7018dd9bf7aac9)): ?>
<?php $attributes = $__attributesOriginald0cc230b3d9e5893ce7018dd9bf7aac9; ?>
<?php unset($__attributesOriginald0cc230b3d9e5893ce7018dd9bf7aac9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0cc230b3d9e5893ce7018dd9bf7aac9)): ?>
<?php $component = $__componentOriginald0cc230b3d9e5893ce7018dd9bf7aac9; ?>
<?php unset($__componentOriginald0cc230b3d9e5893ce7018dd9bf7aac9); ?>
<?php endif; ?>


<div id="contactSection" style="display: none;">
    <div class="container" style="padding: 40px 20px;">
        <div class="kontak-card">
            <div class="info-left">
                <h2><?php echo e(Auth::user()->nama); ?></h2>
                <a href="<?php echo e(Auth::user()->detailUser->website??'#'); ?>" target="_blank" class="visit-button">Visit Website</a>

                <div class="contact-item">
                    <span>📧</span>
                    <p><?php echo e(Auth::user()->email); ?></p>
                </div>

                <div class="contact-item">
                    <span>📞</span>
                    <p><?php echo e(Auth::user()->detailUser->noTlp??'belum dilengkapi'); ?></p>
                </div>

                <div class="contact-item">
                    <span>📍</span>
                    <p><?php echo e(Auth::user()->detailUser->alamat??'belum dilengkapi'); ?></p>
                </div>
            </div>

            <div class="map-right">
                <?php echo Auth::user()->detailUser->link_maps ?? 'belum dilengkapi'; ?>


            </div>
        </div>
        <?php if(Auth::user()->role==="perusahaan"): ?>
        <div class="edit-btn-container">
            <a href="/editprofil-perusahaan" class="edit-btn">Edit Profile</a>
        </div>
        <?php endif; ?>
    </div>

</div>
</div>

<script>
    function showSection(sectionId) {
        // Sembunyikan semua section
        document.getElementById('aboutSection').style.display = 'none';
        document.getElementById('joblistSection').style.display = 'none'; // ← diperbaiki di sini
        document.getElementById('contactSection').style.display = 'none';

        // Reset semua tab
        document.getElementById('btn-about')?.classList.remove('text-primary', 'border-primary', 'fw-bold');
        document.getElementById('btn-about')?.classList.add('text-dark');
        document.getElementById('btn-listjob')?.classList.remove('text-primary', 'border-primary', 'fw-bold');
        document.getElementById('btn-listjob')?.classList.add('text-dark');
        document.getElementById('btn-contact')?.classList.remove('text-primary', 'border-primary', 'fw-bold');
        document.getElementById('btn-contact')?.classList.add('text-dark');

        // Tampilkan section sesuai tombol
        document.getElementById(sectionId).style.display = 'block';

        if (sectionId === 'aboutSection') {
            document.getElementById('btn-about')?.classList.add('text-primary', 'border-bottom', 'border-primary',
                'fw-bold');
            document.getElementById('btn-about')?.classList.remove('text-dark');
        } else if (sectionId === 'joblistSection') {
            document.getElementById('btn-listjob')?.classList.add('text-primary', 'border-bottom', 'border-primary',
                'fw-bold');
            document.getElementById('btn-listjob')?.classList.remove('text-dark');
        } else if (sectionId === 'contactSection') {
            document.getElementById('btn-contact')?.classList.add('text-primary', 'border-bottom', 'border-primary',
                'fw-bold');
            document.getElementById('btn-contact')?.classList.remove('text-dark');
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\Documents\project-php\laravel\Job_portal\resources\views/Profil/Perusahaan/aboutperusahaan.blade.php ENDPATH**/ ?>