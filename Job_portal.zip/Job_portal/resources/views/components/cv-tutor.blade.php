<div class="cv-tutorial">
    <h2>Tutorial Membuat CV/Resume</h2>
    <div class="container-c" style="display: flex;">
        <div class="container-box">
            <div style="flex: 1;">
                <video controls style="width: 100%;">
                    <source src="path/to/your/video.mp4" type="video/mp4">
                    Your browser does not support the video tag.
                </video>
            </div>
            <div class="video-description">
                <p>Video tutorial ini memberikan panduan lengkap dan praktis tentang cara membuat CV/Resume yang menarik
                    dan efektif, mulai dari menyusun informasi pribadi, riwayat pendidikan, pengalaman kerja, hingga
                    menonjolkan keahlian dan pencapaian Anda, serta memberikan tips tentang memilih desain yang tepat
                    agar
                    CV/Resume Anda terlihat profesional dan menarik perhatian perekrut.</p>

            </div>
        </div>
    </div>


</div>
