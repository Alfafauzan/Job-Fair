<footer class="footer text-center py-4">
    <div class="container">
        <img src="{{ asset('images/wnn3.png') }}" alt="" class="footer-logo me-5" width="20">
        <h3 class="mt-3">Contact Us</h3>
        {{-- <p style="text-align: center;  line-height: 2">
            Gigglecorps@company.com <br />
            (123) 29389 9283 9389 <br /><br />
          </p> --}}
        <div class="social-icons mt-2"><a href="#" class="social-icon"><i class="fab fa-facebook"></i></a>
            <a href="#" class="social-icon"><i class="fab fa-twitter"></i></a>
            <a href="#" class="social-icon"><i class="fab fa-instagram"></i></a>
            <a href="#" class="social-icon"><i class="fab fa-linkedin"></i></a>
        </div>
    </div>
</footer>
