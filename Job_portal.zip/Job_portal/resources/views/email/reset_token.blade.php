<p>Berikut adalah kode verifikasi reset password Anda:</p>
<h2>{{ $token }}</h2>
<p>Masukkan kode ini untuk melanjutkan proses reset password.</p>