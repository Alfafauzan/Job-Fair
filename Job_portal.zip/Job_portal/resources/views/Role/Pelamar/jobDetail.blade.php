@extends('layouts.pelamar')

@section('content')
<div class="JobDetail">
<div class="job-detail">
    <div class="job-info">
      <h2>Job Detail</h2>
      <h3>Open Position for UI/UX Designer</h3>
      <h4>About Sevanam:</h4>
      <p>Established since 2020, PT. Sevanam Teknologi Solusindo is engaged in Software Development, especially Microfinance Institutions that focus on Customer Centric towards Customer Satisfaction. Serving 60+ Customers spread across Bali, Central and Eastern Indonesia.</p>
  
      <h4>Requirements:</h4>
      <ul>
        <li>Technical understanding of how to perform software testing.geowiuvivbijbidbvibdaibqevbdubvdabjkdbvbjd idbi</li><br>
        <p>dvbiuewbewi cdj iju</p>
       
      </ul>
  
      <button class="apply-btn">Apply Now</button>
    </div>
  
    <div class="company-info">
      <img src="logo-sevanam.png" alt="Company Logo" class="company-logo">
      <h3>Sevanam</h3>
      <button class="visit-btn">Visit Company</button>
      <img src="software-tester.png" alt="Job Poster" class="job-image">
    </div>
  </div>
  </div>
  
    
@endsection