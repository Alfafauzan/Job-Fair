@extends('layouts.guest')

@section('content')
<div class="container-box-tentangkami">
    <div class="box-tentangkami">
        <img src="{{ asset('images/wnn3.png') }}" alt="">
        <div class="box-desc">
            <h3>Descripsi</h3> 
          </div>
          <hr class="my-4 border border-light border-3">

          <div class="visi-misi">
            <div class="box">
                <h3>Visi</h3>
              </div>
              <div class="box">
                <h3>Misi</h3>
              </div>
          </div>
         
         
          
    </div>
    </div>
    
@endsection